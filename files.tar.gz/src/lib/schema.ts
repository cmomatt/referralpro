import { pgTable, text, timestamp, varchar, pgEnum } from 'drizzle-orm/pg-core';

export const referralStatusEnum = pgEnum('referral_status', [
  'pending',
  'contacted',
  'accepted',
  'rejected',
  'completed'
]);

export const rewardTypeEnum = pgEnum('reward_type', [
  'cash',
  'credit',
  'gift',
  'other'
]);

export const rewardStatusEnum = pgEnum('reward_status', [
  'pending',
  'paid',
  'cancelled'
]);

export const users = pgTable('users', {
  id: text('id').primaryKey(),
  email: varchar('email', { length: 255 }).notNull().unique(),
  name: varchar('name', { length: 255 }).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const referrals = pgTable('referrals', {
  id: text('id').primaryKey(),
  referrerId: text('referrer_id').references(() => users.id).notNull(),
  refereeEmail: varchar('referee_email', { length: 255 }).notNull(),
  refereeName: varchar('referee_name', { length: 255 }),
  status: referralStatusEnum('status').default('pending').notNull(),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
  completedAt: timestamp('completed_at'),
});

export const referralRewards = pgTable('referral_rewards', {
  id: text('id').primaryKey(),
  referralId: text('referral_id').references(() => referrals.id).notNull(),
  type: rewardTypeEnum('type').notNull(),
  amount: text('amount'), // Store as text to handle different currencies
  description: text('description').notNull(),
  status: rewardStatusEnum('status').default('pending').notNull(),
  paidAt: timestamp('paid_at'),
});
