import { db } from './db';
import { users } from './schema';

export async function testDatabaseConnection() {
  try {
    console.log('Testing database connection...');

    // Test the connection by running a simple query
    const result = await db.select().from(users).limit(1);
    console.log('✅ Database connection successful!');
    console.log('Current users in database:', result.length);

    return true;
  } catch (error) {
    console.error('❌ Database connection failed:', error);
    return false;
  }
}
